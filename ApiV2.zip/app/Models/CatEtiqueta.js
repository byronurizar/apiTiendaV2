'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class CatEtiqueta extends Model {
}

module.exports = CatEtiqueta
