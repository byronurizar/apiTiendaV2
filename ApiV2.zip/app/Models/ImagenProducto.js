'use strict'

/** @type {typeof import('@adonisjs/lucid/src/Lucid/Model')} */
const Model = use('Model')

class ImagenProducto extends Model {
}

module.exports = ImagenProducto
