﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    public class Producto
    {
        public int id { get; set; }
        public int idCatalogo { get; set; }
        public int nopagina { get; set; }
        public int idCategoria { get; set; }
        public string nombre { get; set; }
        public string codigo { get; set; }
        public string descripcion { get; set; }
        public string descripcionCorta { get; set; }
        public decimal precio { get; set; }
        public decimal oferta { get; set; }
        public int idEstado { get; set; }

    }
}
