﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
  public class RespuestaApi
    {
        public int codigo { get; set; }
        public string error { get; set; }
        public string respuesta { get; set; }
        public object data { get; set; }
    }
}
