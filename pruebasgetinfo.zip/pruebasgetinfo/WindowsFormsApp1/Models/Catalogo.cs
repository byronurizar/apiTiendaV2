﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    public class Catalogo
    {
        public int id { get; set; }
        public int idProveedor { get; set; }
        public string descripcion { get; set; }
        public int idEstado { get; set; }
        public string url { get; set; }
        public int user_id { get; set; }
        public DateTime created_at { get; set; }
        public DateTime updated_at { get; set; }
    }
}
