﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Models
{
    public class ImagenProducto
    {
        public int id { get; set; }
        public int idProducto { get; set; }
        public bool esImagenPrincipal { get; set; }
        public int idEstado { get; set; }
        public byte[] imagen { get; set; }
    }
}
