﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Models;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var driver = GetDriver();
            driver.Manage().Window.Maximize();
          
            
            categoriaCatalogo(driver);
        }
        public IWebDriver GetDriver()
        {
            var user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36";
            FirefoxOptions options = new FirefoxOptions();
            //Descomenta esta linea para usar el mode HeadLess de Chrome
            //options.AddArgument("--headless"); 
            options.AddArgument("--disable-gpu");
            options.AddArgument($"user_agent={user_agent}");
            options.AddArgument("--ignore-certificate-errors");
            IWebDriver driver = new FirefoxDriver(Directory.GetCurrentDirectory(), options);
            return driver;
        }
        public List<Catalogo> catalogos()
        {
            int idProveedor = 2;
            List<Catalogo> catalogos = new List<Catalogo>();
            Catalogo catalogo = new Catalogo();
            catalogo.idProveedor = idProveedor;
            catalogo.descripcion = "Nutrición";
            catalogo.idEstado = 1;
            catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=CI&line=C&NavM=N";
            catalogos.Add(catalogo);
            
            catalogo = new Catalogo();
            catalogo.idProveedor = idProveedor;
            catalogo.descripcion = "Belleza";
            catalogo.idEstado = 1;
            catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=BA&line=B&NavM=N";
            catalogos.Add(catalogo);

            catalogo.idProveedor = idProveedor;
            catalogo.descripcion = "Cuidado Personal";
            catalogo.idEstado = 1;
            catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=EA&line=E&NavM=N";
            catalogos.Add(catalogo);

            catalogo.idProveedor = idProveedor;
            catalogo.descripcion = "Hogar";
            catalogo.idEstado = 1;
            catalogo.url = "http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=0&C=GB&line=G&NavM=N";
            catalogos.Add(catalogo);
            //driver.Navigate().GoToUrl("http://www.amway.com.gt/");
            //var cate = ObtenerCategorias(driver);
            
            return catalogos;
        }
        public void categoriaCatalogo(IWebDriver driver)
        {
            List<Categoria> categorias = new List<Categoria>();
            foreach (Catalogo catalogo in catalogos())
            {
                RespuestaApi rsp = new RespuestaApi();
                rsp = conectorApi("catalogos/registro", catalogo);
                txtLog.Text += JsonConvert.SerializeObject(rsp);
                txtLog.Text += DateTime.Now + "-----------------------------------";
                if (rsp.codigo == 0)
                {
                    Catalogo responseCatalogo = new Catalogo();
                    responseCatalogo = JsonConvert.DeserializeObject<Catalogo>(rsp.data.ToString());

                    if (responseCatalogo.id > 0)
                    {
                        driver.Navigate().GoToUrl(catalogo.url);
                        var hrefCategorias = driver.FindElements(By.CssSelector(".menu_izq1.menufont_style > div.menu_izq_opciones > a"));
                        foreach (var itemCategoria in hrefCategorias)
                        {
                            Categoria categoria = new Categoria();
                            categoria.descripcion = itemCategoria.Text +"prueba"+ DateTime.Now.ToString("mm:ss");
                            categoria.url = itemCategoria.GetAttribute("href");
                            categoria.idEstado = 1;
                            categorias.Add(categoria);

                            rsp = new RespuestaApi();
                            rsp = conectorApi("categorias/registro", categoria);
                            txtLog.Text += JsonConvert.SerializeObject(rsp);
                            txtLog.Text += DateTime.Now + "-----------------------------------";
                            if (rsp.codigo == 0)
                            {
                                Categoria responseCategoria = new Categoria();
                                responseCategoria = JsonConvert.DeserializeObject<Categoria>(rsp.data.ToString());

                                if (responseCatalogo.id > 0)
                                {
                                    driver.Navigate().GoToUrl(categoria.url);
                                    var listaProductosHml = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));

                                    List<string> urlProductos = new List<string>();
                                        foreach (var itemProducto in listaProductosHml)
                                        {
                                            urlProductos.Add(itemProducto.GetAttribute("href"));
                                        }
                                  

                                    foreach (string url in urlProductos)
                                    {
                                        driver.Navigate().GoToUrl(url);
                                        Producto producto = new Producto();
                                        try
                                        {
                                            var itemHmlNombre = driver.FindElement(By.CssSelector(".nutrilite_txt1.ppage_contenido_tit"));
                                            producto.nombre = itemHmlNombre.Text.Trim();
                                        }
                                        catch { }

                                        try
                                        {
                                            var itemHmlDescripcionCorta = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title"));
                                            producto.descripcionCorta = itemHmlDescripcionCorta.Text.Trim();
                                        }
                                        catch { }

                                        string descripcionProducto = string.Empty;
                                        try
                                        {
                                            var itemHmlDescripcion = driver.FindElement(By.CssSelector(".ppage_contenido_des > span"));
                                            descripcionProducto = itemHmlDescripcion.Text.Trim();
                                        }
                                        catch { }

                                        try
                                        {
                                            var itemHmlCapsulas = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title2 > span"));
                                            descripcionProducto += " " + itemHmlCapsulas.Text;
                                        }
                                        catch { }

                                        producto.descripcion = descripcionProducto;

                                        try
                                        {
                                            var itemHmlPrecio = driver.FindElement(By.CssSelector(".valor > span"));
                                            decimal parsePrecio = Convert.ToDecimal(itemHmlPrecio.Text.Replace("Q", string.Empty));
                                            if (parsePrecio > 100)
                                            {
                                                producto.precio = parsePrecio;
                                            }
                                        }
                                        catch { }

                                        string urlImagen = "http://www.amway.com.gt/";
                                        try
                                        {
                                            var itemHtmlImagen = driver.FindElement(By.CssSelector(".zoomWindow"));
                                            string auxUrl= itemHtmlImagen.GetAttribute("style");
                                            auxUrl = auxUrl.Replace("url(","|");
                                            auxUrl = auxUrl.Replace(");", "|");
                                            string[] auxUrl2 = auxUrl.Split('|');
                                            urlImagen += auxUrl[3];

                                            string pathSave = Application.StartupPath+"/Imagenes";
                                            try
                                            {
                                                if (!(Directory.Exists(pathSave)))
                                                {
                                                    Directory.CreateDirectory(pathSave);
                                                }
                                            }
                                            catch (Exception ex)
                                            {

                                            }

                                            using (WebClient client = new WebClient())
                                            {
                                                client.DownloadFile(new Uri(urlImagen), pathSave+"/"+producto.codigo+".png");
                                            }
                                           

                                        }
                                        catch { }
                                        //productos.Add(producto);

                                        producto.nopagina = 0;
                                        producto.idCatalogo = responseCatalogo.id;
                                        producto.idCategoria = responseCategoria.id;
                                        producto.oferta = 0;
                                        producto.idEstado = 1;

                                        string extrarCodigo = string.Empty;
                                        extrarCodigo = url;
                                        extrarCodigo = extrarCodigo.Replace("C&BC=", "|");
                                        extrarCodigo = extrarCodigo.Replace("&C", "|");
                                        string[] itemsCodigo = extrarCodigo.Split('|');
                                        string codigo = itemsCodigo[1];
                                        producto.codigo = codigo;

                                        rsp = new RespuestaApi();
                                        rsp = conectorApi("productos/registro", producto);
                                        txtLog.Text += JsonConvert.SerializeObject(rsp);
                                        txtLog.Text += DateTime.Now + "-----------------------------------";
                                        if (rsp.codigo == 0)
                                        {
                                            Producto responseProducto = new Producto();
                                            responseProducto = JsonConvert.DeserializeObject<Producto>(rsp.data.ToString());

                                            if (responseProducto.id > 0)
                                            {
                                                try
                                                {
                                                    var listaInfoAdicionalProductosHml = driver.FindElements(By.CssSelector(".tabs.ui-tabs.ui-widget.ui-widget-content.ui-corner-all > ul > li > a"));
                                                    int contadorTabs = 0;
                                                    foreach (var itemTab in listaInfoAdicionalProductosHml)
                                                    {
                                                        InfoAdicionalProducto infoAdicional = new InfoAdicionalProducto();

                                                        IWebElement contenidoTab = itemTab;
                                                        if (contadorTabs > 0)
                                                        {
                                                            ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", contenidoTab);
                                                        }

                                                        string titulo = itemTab.Text;
                                                        string descripcionContenidoTab = string.Empty;
                                                        string idContenido = itemTab.GetAttribute("href").Split('#')[1];
                                                        var descripInfoAdicionalHtml = driver.FindElement(By.Id(idContenido));
                                                        descripcionContenidoTab = descripInfoAdicionalHtml.Text;
                                                        infoAdicional.idEstado = 1;
                                                        infoAdicional.idProducto = responseProducto.id;
                                                        infoAdicional.valor = descripcionContenidoTab;
                                                        if (titulo.Contains("Beneficios"))
                                                        {
                                                            infoAdicional.idTipoInfoAdicional = 1;
                                                        }
                                                        else if (titulo.Contains("Instrucciones de uso"))
                                                        {
                                                            infoAdicional.idTipoInfoAdicional = 2;
                                                        }
                                                        else if (titulo.Contains("Preguntas frecuentes"))
                                                        {
                                                            infoAdicional.idTipoInfoAdicional = 4;
                                                        }
                                                        else if (titulo.Contains("Advertencias"))
                                                        {
                                                            infoAdicional.idTipoInfoAdicional = 3;
                                                        }
                                                        else
                                                        {
                                                            CatTipoInfoAdicional tipoInfoAdicional = new CatTipoInfoAdicional();
                                                            tipoInfoAdicional.idEstado = 1;
                                                            tipoInfoAdicional.descripcion = titulo.Trim();
                                                            rsp = new RespuestaApi();
                                                            rsp = conectorApi("tipoinfoadicional/producto", tipoInfoAdicional);
                                                            txtLog.Text += JsonConvert.SerializeObject(rsp);
                                                            txtLog.Text += DateTime.Now + "-----------------------------------";
                                                            if (rsp.codigo == 0)
                                                            {
                                                                CatTipoInfoAdicional responseCatTipoInfoAdicional = new CatTipoInfoAdicional();
                                                                responseCatTipoInfoAdicional = JsonConvert.DeserializeObject<CatTipoInfoAdicional>(rsp.data.ToString());
                                                                if (responseCatTipoInfoAdicional.id > 0)
                                                                {
                                                                    infoAdicional.idTipoInfoAdicional = responseCatTipoInfoAdicional.id;
                                                                }
                                                            }
                                                        }

                                                        rsp = new RespuestaApi();
                                                        rsp = conectorApi("productos/infoadicional", infoAdicional);
                                                        txtLog.Text += JsonConvert.SerializeObject(rsp);
                                                        txtLog.Text += DateTime.Now + "-----------------------------------";
                                                        if (rsp.codigo == 0)
                                                        {

                                                        }
                                                        contadorTabs++;

                                                    }
                                                }
                                                catch { }


                                               //Image
                                            }
                                        }

                                        //Registrar Imagen
                                        try
                                        {
                                            string urlImagenPrueba = "http://www.amway.com.gt/img_pict/260_Catalog/Products/full/260_110609.jpg";
                                            WebClient clientImagen = new WebClient();
                                            byte[] bites = clientImagen.DownloadData(urlImagenPrueba);
                                            ImagenProducto imgProducto = new ImagenProducto();
                                            imgProducto.idProducto = 12;
                                            imgProducto.esImagenPrincipal = true;
                                            imgProducto.idEstado = 1;
                                            imgProducto.imagen = bites;
                                            rsp = new RespuestaApi();



                                            rsp = conectorApi("productos/imagenes/registro", imgProducto,true);
                                            txtLog.Text += JsonConvert.SerializeObject(rsp);
                                            txtLog.Text += DateTime.Now + "-----------------------------------";
                                            if (rsp.codigo == 0)
                                            {

                                            }
                                        }
                                        catch { }


                                    }
                                }
                            }
                        }
                    }
                }
               
                
                break;
            }
            /*
            List<string> urlProductos = new List<string>();
            foreach (Categoria itemCategoria in categorias)
            {
                driver.Navigate().GoToUrl(itemCategoria.url);
                var listaProductosHml = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));
                foreach (var itemProducto in listaProductosHml)
                {
                    urlProductos.Add(itemProducto.GetAttribute("href"));
                }
                break;
            }
            List<Producto> productos = new List<Producto>();
            foreach (string item in urlProductos)
            {
                driver.Navigate().GoToUrl(item);
                Producto producto = new Producto();
                try
                {
                    var itemHmlNombre = driver.FindElement(By.CssSelector(".nutrilite_txt1.ppage_contenido_tit"));
                    producto.nombre = itemHmlNombre.Text.Trim();
                }catch{}

                try
                {
                    var itemHmlDescripcionCorta = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title"));
                    producto.descripcionCorta = itemHmlDescripcionCorta.Text.Trim();
                }catch{}

                string descripcionProducto = string.Empty;
                try
                {
                    var itemHmlDescripcion = driver.FindElement(By.CssSelector(".ppage_contenido_des > span"));
                    descripcionProducto= itemHmlDescripcion.Text.Trim();
                }catch{}

                try
                {
                    var itemHmlCapsulas = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title2 > span"));
                    descripcionProducto= " " + itemHmlCapsulas.Text;
                }catch{}

                producto.descripcion = descripcionProducto;

                try
                {
                    var itemHmlPrecio = driver.FindElement(By.CssSelector(".valor > span"));
                    decimal parsePrecio = Convert.ToDecimal(itemHmlPrecio.Text.Replace("Q", string.Empty));
                    if (parsePrecio > 100)
                    {
                        producto.precio = parsePrecio;
                    }
                }catch{}
                productos.Add(producto);

                try
                {
                    var listaInfoAdicionalProductosHml = driver.FindElements(By.CssSelector(".tabs.ui-tabs.ui-widget.ui-widget-content.ui-corner-all > ul > li > a"));
                    int contadorTabs = 0;
                    foreach (var itemTab in listaInfoAdicionalProductosHml)
                    {
                        
                            IWebElement contenidoTab = itemTab;
                            if (contadorTabs > 0)
                            {
                                ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", contenidoTab);
                            }
                        
                            string titulo = itemTab.Text;
                            string descripcionContenidoTab = string.Empty;
                            string idContenido = itemTab.GetAttribute("href").Split('#')[1];
                            var descripInfoAdicionalHtml = driver.FindElement(By.Id(idContenido));
                            contadorTabs++;
                    }
                }
                catch { }
            }
            */
        }

        public RespuestaApi conectorApi(string url, object jsonData,bool imagen=false)
        {
            string BaseUri = "http://api.misapps.tk/apiStore/v1/";
            string token = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjMsImlhdCI6MTU5NTYwMzQxNX0.kHZP9lQa75dbniwzw6xjZYUNk1AqQ_7I-mo3A3mQJfo";

            RespuestaApi rs = new RespuestaApi();
            try
            {
                
                HttpClient client = new HttpClient();
                client.BaseAddress = new Uri(BaseUri);
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Add("Authorization", token);

                HttpResponseMessage response = null;

                if (!imagen)
                {
                    response = client.PostAsJsonAsync(url, jsonData).Result;
                }
                else
                {
                    var formData = new MultipartFormDataContent();

                    ImagenProducto img = new ImagenProducto();
                    img = JsonConvert.DeserializeObject<ImagenProducto>(jsonData.ToString());

                    HttpContent producto = new StringContent(img.idProducto.ToString());
                    HttpContent esImagenPrincipal = new StringContent(img.esImagenPrincipal.ToString());
                    HttpContent idEstado = new StringContent(img.idEstado.ToString());
                    HttpContent bytesContent = new ByteArrayContent(img.imagen);

                    formData.Add(producto, "ImagenProducto", "ImagenProducto");
                    formData.Add(esImagenPrincipal, "esImagenPrincipal", "esImagenPrincipal");
                    formData.Add(idEstado, "idEstado", "idEstado");
                    formData.Add(bytesContent, "imagen", "imagen");
                    response = client.PostAsJsonAsync(url, formData).Result;
                }
                    
                
                if (response.IsSuccessStatusCode)
                {
                    var Catalogo = response.Content.ReadAsStringAsync();
                    string qryResult = Catalogo.Result;
                    var datos = (RespuestaApi)JsonConvert.DeserializeObject(qryResult, typeof(RespuestaApi));
                    rs = (RespuestaApi)datos;
                }
                else
                {
                    rs.codigo = (int)response.StatusCode;
                    rs.error = response.ReasonPhrase;
                    rs.data = null;
                }
            }
            catch
            {
                throw new Exception("Ocurrió un error al realizar la petición");
            }
            return rs;
        }
        public void registrarProductos(IWebDriver driver,List<Categoria> categorias)
        {
            //foreach (Categoria itemCategoria in categorias)
            //{
                driver.Navigate().GoToUrl("http://www.amway.com.gt/Store/Catalogue.aspx?show=Top&line=G");
             //var hrefItemProductos = driver.FindElements(By.CssSelector(".nav_content_inf > div.nav1 > a"));
            //IWebElement tabsPaginas = driver.FindElement(By.CssSelector("#ctl00_CategoriesBox1_rptData_ctl04_li > a"));

            //((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", tabsPaginas);
            //tabsPaginas.Click();

            List<string> listaUrlProductos = new List<string>();
            var listaProductosHml = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));
            foreach (var itemProducto in listaProductosHml)
            {
                listaUrlProductos.Add(itemProducto.GetAttribute("href"));
            }

            /* Click a 
            int contador = 0;
            foreach (var item in hrefItemProductos)
            {
                IWebElement pagina = item;
                contador++;
                if (contador > 1)
                {
                    ((IJavaScriptExecutor)driver).ExecuteScript("arguments[0].click();", pagina);
                }

            }
            */
            
        }
        public List<string> ObtenerCategorias(IWebDriver driver)
        {
            List<string> categorias = new List<string>();
            var links = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));

            List<string> urls = new List<string>();

            foreach (var item in links)
            {
                //if (item.Text.Length > 0)
                //{
                var url = item.GetAttribute("href");
                urls.Add(url);
                //var inicio = url.LastIndexOf('_') + 1;
                //var largo = url.LastIndexOf('/') - inicio;

                //}
            }

            string precio;
            string descripcionCorta;
            string descripcion;
            string codigo;
            foreach (string item in urls)
            {
                driver.Navigate().GoToUrl(item);
                var desc = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title"));
                descripcionCorta = desc.Text;
                var desc2 = driver.FindElement(By.CssSelector(".ppage_contenido_des > span"));
                descripcion = desc2.Text;
                codigo = item.Substring(item.IndexOf("C&BC="), 3);

                var precio2 = driver.FindElement(By.CssSelector(".valor > span"));
                precio = precio2.Text;
            }

            return categorias;
        }
    }
}
