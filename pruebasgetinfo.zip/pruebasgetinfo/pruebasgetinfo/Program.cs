﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pruebasgetinfo
{
    class Program
    {
        static void Main(string[] args)
        {
            var driver = GetDriver();
            driver.Manage().Window.Maximize();
            GuardarCategorias(driver);
        }
        public static IWebDriver GetDriver()
        {
            var user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.50 Safari/537.36";
            FirefoxOptions options = new FirefoxOptions();
            //Descomenta esta linea para usar el mode HeadLess de Chrome
            //options.AddArgument("--headless"); 
            options.AddArgument("--disable-gpu");
            options.AddArgument($"user_agent={user_agent}");
            options.AddArgument("--ignore-certificate-errors");
            string directorio = Directory.GetCurrentDirectory();
            IWebDriver driver = new FirefoxDriver(Directory.GetCurrentDirectory(), options);
            return driver;
        }
        public static void GuardarCategorias(IWebDriver driver)
        {
            
                driver.Navigate().GoToUrl("http://www.amway.com.gt/Store/Catalogue.aspx?show=PrdsList&IC=1&C=CJ&line=C&NavM=N");
                var cate = ObtenerCategorias(driver);
        }
        public static List<string> ObtenerCategorias(IWebDriver driver)
        {
            List<string> categorias = new List<string>();
            var links = driver.FindElements(By.CssSelector(".allproducts_product_sec1 > div.allproducts_product_sec1_image> a"));

            List<string> urls = new List<string>();

            foreach (var item in links)
            {
                //if (item.Text.Length > 0)
                //{
                var url = item.GetAttribute("href");
                urls.Add(url);
                //var inicio = url.LastIndexOf('_') + 1;
                //var largo = url.LastIndexOf('/') - inicio;

                //}
            }

            string precio;
            string descripcionCorta;
            string descripcion;
            string codigo;
            foreach (string item in urls)
            {
                driver.Navigate().GoToUrl(item);
                var desc = driver.FindElement(By.CssSelector(".ppage_contenido_sub_title"));
                descripcionCorta = desc.Text;
                var desc2 = driver.FindElement(By.CssSelector(".ppage_contenido_des > span"));
                descripcion = desc2.Text;
                codigo = item.Substring(item.IndexOf("C&BC="), 3);

                var precio2 = driver.FindElement(By.CssSelector(".valor > span"));
                precio = precio2.Text;
            }

            return categorias;
        }
    }
}
