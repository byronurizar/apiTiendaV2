-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: miscomprasdesa
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vistadetallepedido`
--

DROP TABLE IF EXISTS `vistadetallepedido`;
/*!50001 DROP VIEW IF EXISTS `vistadetallepedido`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistadetallepedido` AS SELECT 
 1 AS `id`,
 1 AS `IdProducto`,
 1 AS `Producto`,
 1 AS `codigo`,
 1 AS `cantidad`,
 1 AS `Precio`,
 1 AS `Talla`,
 1 AS `Color`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaroles`
--

DROP TABLE IF EXISTS `vistaroles`;
/*!50001 DROP VIEW IF EXISTS `vistaroles`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaroles` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistadepartamentos`
--

DROP TABLE IF EXISTS `vistadepartamentos`;
/*!50001 DROP VIEW IF EXISTS `vistadepartamentos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistadepartamentos` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistatelefonosproveedor`
--

DROP TABLE IF EXISTS `vistatelefonosproveedor`;
/*!50001 DROP VIEW IF EXISTS `vistatelefonosproveedor`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistatelefonosproveedor` AS SELECT 
 1 AS `id`,
 1 AS `idProveedor`,
 1 AS `telefono`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaimagenesproducto`
--

DROP TABLE IF EXISTS `vistaimagenesproducto`;
/*!50001 DROP VIEW IF EXISTS `vistaimagenesproducto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaimagenesproducto` AS SELECT 
 1 AS `id`,
 1 AS `idProducto`,
 1 AS `pathImagen`,
 1 AS `codigoImagen`,
 1 AS `esImagenPrincipal`,
 1 AS `idEstado`,
 1 AS `user_id`,
 1 AS `created_at`,
 1 AS `updated_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaetiquetasproducto`
--

DROP TABLE IF EXISTS `vistaetiquetasproducto`;
/*!50001 DROP VIEW IF EXISTS `vistaetiquetasproducto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaetiquetasproducto` AS SELECT 
 1 AS `id`,
 1 AS `idEtiqueta`,
 1 AS `idEstado`,
 1 AS `productoid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistadetalletipopago`
--

DROP TABLE IF EXISTS `vistadetalletipopago`;
/*!50001 DROP VIEW IF EXISTS `vistadetalletipopago`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistadetalletipopago` AS SELECT 
 1 AS `id`,
 1 AS `nombreBanco`,
 1 AS `idTipoPago`,
 1 AS `nombreCuenta`,
 1 AS `numeroCuenta`,
 1 AS `tipoCuenta`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistacatalogos`
--

DROP TABLE IF EXISTS `vistacatalogos`;
/*!50001 DROP VIEW IF EXISTS `vistacatalogos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistacatalogos` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idProveedor`,
 1 AS `idEstado`,
 1 AS `proveedorid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistainfopedido`
--

DROP TABLE IF EXISTS `vistainfopedido`;
/*!50001 DROP VIEW IF EXISTS `vistainfopedido`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistainfopedido` AS SELECT 
 1 AS `id`,
 1 AS `Fecha`,
 1 AS `Nombre`,
 1 AS `telefonos`,
 1 AS `direccion`,
 1 AS `puntoReferencia`,
 1 AS `TipoPago`,
 1 AS `Estado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistacategorias`
--

DROP TABLE IF EXISTS `vistacategorias`;
/*!50001 DROP VIEW IF EXISTS `vistacategorias`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistacategorias` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistamunicipios`
--

DROP TABLE IF EXISTS `vistamunicipios`;
/*!50001 DROP VIEW IF EXISTS `vistamunicipios`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistamunicipios` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idDepartamento`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaproveedores`
--

DROP TABLE IF EXISTS `vistaproveedores`;
/*!50001 DROP VIEW IF EXISTS `vistaproveedores`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaproveedores` AS SELECT 
 1 AS `id`,
 1 AS `nombre`,
 1 AS `descripcion`,
 1 AS `direccion`,
 1 AS `idEstado`,
 1 AS `num_dias_minimo_ciudad`,
 1 AS `num_dias_maximo_ciudad`,
 1 AS `num_dias_minimo_interior`,
 1 AS `num_dias_maximo_interior`,
 1 AS `observaciones`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistacolores`
--

DROP TABLE IF EXISTS `vistacolores`;
/*!50001 DROP VIEW IF EXISTS `vistacolores`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistacolores` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistatallas`
--

DROP TABLE IF EXISTS `vistatallas`;
/*!50001 DROP VIEW IF EXISTS `vistatallas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistatallas` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistacoloresproducto`
--

DROP TABLE IF EXISTS `vistacoloresproducto`;
/*!50001 DROP VIEW IF EXISTS `vistacoloresproducto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistacoloresproducto` AS SELECT 
 1 AS `id`,
 1 AS `idColor`,
 1 AS `idEstado`,
 1 AS `productoid`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `menupublico`
--

DROP TABLE IF EXISTS `menupublico`;
/*!50001 DROP VIEW IF EXISTS `menupublico`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `menupublico` AS SELECT 
 1 AS `id`,
 1 AS `idpadre`,
 1 AS `descripcion`,
 1 AS `href`,
 1 AS `icono`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistacomercioproductos`
--

DROP TABLE IF EXISTS `vistacomercioproductos`;
/*!50001 DROP VIEW IF EXISTS `vistacomercioproductos`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistacomercioproductos` AS SELECT 
 1 AS `id`,
 1 AS `nombre`,
 1 AS `descripcion`,
 1 AS `descripcionCorta`,
 1 AS `precio`,
 1 AS `oferta`,
 1 AS `pathImagen`,
 1 AS `esImagenPrincipal`,
 1 AS `idCatalogo`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaestadopedido`
--

DROP TABLE IF EXISTS `vistaestadopedido`;
/*!50001 DROP VIEW IF EXISTS `vistaestadopedido`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaestadopedido` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistaetiquetas`
--

DROP TABLE IF EXISTS `vistaetiquetas`;
/*!50001 DROP VIEW IF EXISTS `vistaetiquetas`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistaetiquetas` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistatiposdepago`
--

DROP TABLE IF EXISTS `vistatiposdepago`;
/*!50001 DROP VIEW IF EXISTS `vistatiposdepago`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistatiposdepago` AS SELECT 
 1 AS `id`,
 1 AS `descripcion`,
 1 AS `esTipoDeposito`,
 1 AS `idEstado`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vistatallasproducto`
--

DROP TABLE IF EXISTS `vistatallasproducto`;
/*!50001 DROP VIEW IF EXISTS `vistatallasproducto`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vistatallasproducto` AS SELECT 
 1 AS `id`,
 1 AS `idTalla`,
 1 AS `idEstado`,
 1 AS `productoid`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vistadetallepedido`
--

/*!50001 DROP VIEW IF EXISTS `vistadetallepedido`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistadetallepedido` AS select `a`.`idPedido` AS `id`,`b`.`id` AS `IdProducto`,`b`.`nombre` AS `Producto`,`b`.`codigo` AS `codigo`,`a`.`cantidad` AS `cantidad`,(`a`.`precio` - `a`.`descuento`) AS `Precio`,(case when (`c`.`descripcion` is null) then 'N/A' else `c`.`descripcion` end) AS `Talla`,(case when (`d`.`descripcion` is null) then 'N/A' else `d`.`descripcion` end) AS `Color` from (((`detalle_pedidos` `a` join `productos` `b` on((`a`.`idProducto` = `b`.`id`))) left join `talla_productos` `c` on((`a`.`idTalla` = `c`.`id`))) left join `cat_colores` `d` on((`a`.`idTalla` = `d`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaroles`
--

/*!50001 DROP VIEW IF EXISTS `vistaroles`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaroles` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_rols` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistadepartamentos`
--

/*!50001 DROP VIEW IF EXISTS `vistadepartamentos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistadepartamentos` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_departamentos` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistatelefonosproveedor`
--

/*!50001 DROP VIEW IF EXISTS `vistatelefonosproveedor`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistatelefonosproveedor` AS select `a`.`id` AS `id`,`b`.`nombre` AS `idProveedor`,`a`.`telefono` AS `telefono`,`c`.`descripcion` AS `idEstado` from ((`cat_telefono_proveedors` `a` join `proveedors` `b` on((`a`.`idProveedor` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaimagenesproducto`
--

/*!50001 DROP VIEW IF EXISTS `vistaimagenesproducto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaimagenesproducto` AS select `imagen_productos`.`id` AS `id`,`imagen_productos`.`idProducto` AS `idProducto`,concat(`imagen_productos`.`pathImagen`) AS `pathImagen`,`imagen_productos`.`codigoImagen` AS `codigoImagen`,`imagen_productos`.`esImagenPrincipal` AS `esImagenPrincipal`,`imagen_productos`.`idEstado` AS `idEstado`,`imagen_productos`.`user_id` AS `user_id`,`imagen_productos`.`created_at` AS `created_at`,`imagen_productos`.`updated_at` AS `updated_at` from `imagen_productos` where (`imagen_productos`.`idEstado` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaetiquetasproducto`
--

/*!50001 DROP VIEW IF EXISTS `vistaetiquetasproducto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaetiquetasproducto` AS select `a`.`id` AS `id`,`b`.`descripcion` AS `idEtiqueta`,`c`.`descripcion` AS `idEstado`,`a`.`idProducto` AS `productoid` from ((`cat_etiqueta_productos` `a` join `cat_etiquetas` `b` on((`a`.`idEtiqueta` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where ((`a`.`idEstado` in (1,2)) and (`b`.`idEstado` in (1,2))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistadetalletipopago`
--

/*!50001 DROP VIEW IF EXISTS `vistadetalletipopago`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistadetalletipopago` AS select `a`.`id` AS `id`,`a`.`nombreBanco` AS `nombreBanco`,`b`.`descripcion` AS `idTipoPago`,`a`.`nombreCuenta` AS `nombreCuenta`,`a`.`numeroCuenta` AS `numeroCuenta`,`a`.`tipoCuenta` AS `tipoCuenta`,`c`.`descripcion` AS `idEstado` from ((`detalle_tipo_pagos` `a` join `cat_tipo_pagos` `b` on((`a`.`idTipoPago` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistacatalogos`
--

/*!50001 DROP VIEW IF EXISTS `vistacatalogos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacatalogos` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`nombre` AS `idProveedor`,`c`.`descripcion` AS `idEstado`,`b`.`id` AS `proveedorid` from ((`catalogos` `a` join `proveedors` `b` on((`a`.`idProveedor` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistainfopedido`
--

/*!50001 DROP VIEW IF EXISTS `vistainfopedido`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistainfopedido` AS select `a`.`id` AS `id`,`a`.`created_at` AS `Fecha`,concat(`b`.`nombres`,' ',`b`.`apellidos`) AS `Nombre`,`b`.`telefonos` AS `telefonos`,`b`.`direccion` AS `direccion`,`b`.`puntoReferencia` AS `puntoReferencia`,`c`.`descripcion` AS `TipoPago`,`d`.`descripcion` AS `Estado` from (((`pedidos` `a` join `info_recibe_pedidos` `b` on((`a`.`id` = `b`.`idPedido`))) join `cat_tipo_pagos` `c` on((`a`.`idTipoPago` = `c`.`id`))) join `cat_estado_pedidos` `d` on((`a`.`idEstadoPedido` = `d`.`id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistacategorias`
--

/*!50001 DROP VIEW IF EXISTS `vistacategorias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacategorias` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_categorias` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistamunicipios`
--

/*!50001 DROP VIEW IF EXISTS `vistamunicipios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistamunicipios` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idDepartamento`,`c`.`descripcion` AS `idEstado` from ((`cat_municipios` `a` join `cat_departamentos` `b` on((`a`.`idDepartamento` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaproveedores`
--

/*!50001 DROP VIEW IF EXISTS `vistaproveedores`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaproveedores` AS select `a`.`id` AS `id`,`a`.`nombre` AS `nombre`,`a`.`descripcion` AS `descripcion`,`a`.`direccion` AS `direccion`,`b`.`descripcion` AS `idEstado`,`a`.`num_dias_minimo_ciudad` AS `num_dias_minimo_ciudad`,`a`.`num_dias_maximo_ciudad` AS `num_dias_maximo_ciudad`,`a`.`num_dias_minimo_interior` AS `num_dias_minimo_interior`,`a`.`num_dias_maximo_interior` AS `num_dias_maximo_interior`,`a`.`observaciones` AS `observaciones` from (`proveedors` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistacolores`
--

/*!50001 DROP VIEW IF EXISTS `vistacolores`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacolores` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_colores` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistatallas`
--

/*!50001 DROP VIEW IF EXISTS `vistatallas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistatallas` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`talla_productos` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistacoloresproducto`
--

/*!50001 DROP VIEW IF EXISTS `vistacoloresproducto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacoloresproducto` AS select `a`.`id` AS `id`,`b`.`descripcion` AS `idColor`,`c`.`descripcion` AS `idEstado`,`a`.`idProducto` AS `productoid` from ((`asig_color_productos` `a` join `cat_colores` `b` on((`a`.`idColor` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where ((`a`.`idEstado` in (1,2)) and (`b`.`idEstado` in (1,2))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `menupublico`
--

/*!50001 DROP VIEW IF EXISTS `menupublico`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `menupublico` AS select concat('prov',`proveedors`.`id`) AS `id`,0 AS `idpadre`,`proveedors`.`nombre` AS `descripcion`,'Soy proveedor' AS `href`,'icono' AS `icono` from `proveedors` where (`proveedors`.`idEstado` = 1) union all select concat('cat',`catalogos`.`id`) AS `id`,concat('prov',`catalogos`.`idProveedor`) AS `idpadre`,`catalogos`.`descripcion` AS `descripcion`,'soy catalogo' AS `href`,'' AS `icono` from `catalogos` where (`catalogos`.`idEstado` = 1) union all select `cat`.`id` AS `id`,concat('cat',`prod`.`idCatalogo`) AS `idpadre`,`cat`.`descripcion` AS `descripcion`,'demo' AS `href`,'' AS `icono` from (((`productos` `prod` join `cat_categorias` `cat` on(((`prod`.`idCategoria` = `cat`.`id`) and (`cat`.`idEstado` = 1) and (`prod`.`idEstado` = 1)))) join `catalogos` `ctlog` on(((`prod`.`idCatalogo` = `ctlog`.`id`) and (`ctlog`.`idEstado` = 1)))) join `proveedors` `prov` on(((`ctlog`.`idProveedor` = `prov`.`id`) and (`prov`.`idEstado` = 1)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistacomercioproductos`
--

/*!50001 DROP VIEW IF EXISTS `vistacomercioproductos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistacomercioproductos` AS select `a`.`id` AS `id`,`a`.`nombre` AS `nombre`,`a`.`descripcion` AS `descripcion`,`a`.`descripcionCorta` AS `descripcionCorta`,`a`.`precio` AS `precio`,`a`.`oferta` AS `oferta`,concat(`b`.`pathImagen`,`b`.`codigoImagen`) AS `pathImagen`,`b`.`esImagenPrincipal` AS `esImagenPrincipal`,`a`.`idCatalogo` AS `idCatalogo` from (`productos` `a` join `imagen_productos` `b` on((`a`.`id` = `b`.`idProducto`))) where ((`a`.`idEstado` = 1) and (`b`.`idEstado` = 1) and (`b`.`esImagenPrincipal` = 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaestadopedido`
--

/*!50001 DROP VIEW IF EXISTS `vistaestadopedido`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaestadopedido` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_estado_pedidos` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistaetiquetas`
--

/*!50001 DROP VIEW IF EXISTS `vistaetiquetas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistaetiquetas` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`b`.`descripcion` AS `idEstado` from (`cat_etiquetas` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistatiposdepago`
--

/*!50001 DROP VIEW IF EXISTS `vistatiposdepago`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistatiposdepago` AS select `a`.`id` AS `id`,`a`.`descripcion` AS `descripcion`,`a`.`esTipoDeposito` AS `esTipoDeposito`,`b`.`descripcion` AS `idEstado` from (`cat_tipo_pagos` `a` join `cat_estados` `b` on((`a`.`idEstado` = `b`.`id`))) where (`a`.`idEstado` in (1,2)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vistatallasproducto`
--

/*!50001 DROP VIEW IF EXISTS `vistatallasproducto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`desarrollo`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vistatallasproducto` AS select `a`.`id` AS `id`,`b`.`descripcion` AS `idTalla`,`c`.`descripcion` AS `idEstado`,`a`.`idProducto` AS `productoid` from ((`asig_talla_productos` `a` join `talla_productos` `b` on((`a`.`idTalla` = `b`.`id`))) join `cat_estados` `c` on((`a`.`idEstado` = `c`.`id`))) where ((`a`.`idEstado` in (1,2)) and (`b`.`idEstado` in (1,2))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-23 21:57:23
