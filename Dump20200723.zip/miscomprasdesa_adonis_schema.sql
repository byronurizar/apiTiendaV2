-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: miscomprasdesa
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adonis_schema`
--

DROP TABLE IF EXISTS `adonis_schema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `adonis_schema` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `batch` int DEFAULT NULL,
  `migration_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adonis_schema`
--

LOCK TABLES `adonis_schema` WRITE;
/*!40000 ALTER TABLE `adonis_schema` DISABLE KEYS */;
INSERT INTO `adonis_schema` VALUES (1,'1503250034269_user',1,'2020-06-20 04:11:07'),(2,'1503250034279_cat_estado_schema',1,'2020-06-20 04:11:08'),(3,'1503250034280_token',1,'2020-06-20 04:11:08'),(4,'1570058906731_cliente_schema',1,'2020-06-20 04:11:08'),(5,'1570072443433_cat_estado_pedido_schema',1,'2020-06-20 04:11:09'),(6,'1570072443433_cat_etiqueta_schema',1,'2020-06-20 04:11:10'),(7,'1570072443433_cat_genero_schema',1,'2020-06-20 04:11:10'),(8,'1570072443433_cat_tipo_pago_schema',1,'2020-06-20 04:11:10'),(9,'1570072707722_cat_categoria_schema',1,'2020-06-20 04:11:11'),(10,'1570072817932_cat_departamento_schema',1,'2020-06-20 04:11:12'),(11,'1570072864194_cat_municipio_schema',1,'2020-06-20 04:11:13'),(12,'1570072924603_cat_rol_schema',1,'2020-06-20 04:11:14'),(13,'1570159960787_proveedor_schema',1,'2020-06-20 04:11:15'),(14,'1570159960788_catalogo_schema',1,'2020-06-20 04:11:17'),(15,'1570160920694_cat_telefono_proveedor_schema',1,'2020-06-20 04:11:17'),(16,'1570207386646_producto_schema',1,'2020-06-20 04:11:18'),(17,'1570212567759_info_adicional_producto_schema',1,'2020-06-20 04:11:20'),(18,'1570213468520_cat_etiqueta_producto_schema',1,'2020-06-20 04:11:20'),(19,'1570219242406_stock_producto_schema',1,'2020-06-20 04:11:21'),(20,'1570219627585_talla_producto_schema',1,'2020-06-20 04:11:22'),(21,'1570491333406_cat_colores_schema',1,'2020-06-20 04:11:23'),(22,'1570504856601_imagen_producto_schema',1,'2020-06-20 04:11:23'),(23,'1570545655232_producto_cruzado_schema',1,'2020-06-20 04:11:24'),(24,'1570546878049_detalle_producto_cruzado_schema',1,'2020-06-20 04:11:26'),(25,'1570565004660_persona_schema',1,'2020-06-20 04:11:27'),(26,'1570566613011_telefono_persona_schema',1,'2020-06-20 04:11:29'),(27,'1570567792075_direccion_persona_schema',1,'2020-06-20 04:11:30'),(28,'1570568877109_pedido_schema',1,'2020-06-20 04:11:31'),(29,'1570571559674_detalle_pedido_schema',1,'2020-06-20 04:11:32'),(30,'1570572790544_detalle_tipo_pago_schema',1,'2020-06-20 04:11:34'),(31,'1576702302967_asig_color_producto_schema',1,'2020-06-20 04:11:34'),(32,'1576706156389_asig_talla_producto_schema',1,'2020-06-20 04:11:36'),(33,'1577724228166_info_recibe_pedido_schema',1,'2020-06-20 04:11:37'),(34,'1592530622898_menu_schema',1,'2020-06-20 04:11:37');
/*!40000 ALTER TABLE `adonis_schema` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-23 21:57:19
