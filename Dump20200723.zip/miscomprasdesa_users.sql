-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: miscomprasdesa
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL,
  `email` varchar(254) NOT NULL,
  `password` varchar(60) DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `proveedor` varchar(50) DEFAULT NULL,
  `uid` varchar(60) DEFAULT NULL,
  `urlfoto` varchar(200) DEFAULT NULL,
  `idRol` int DEFAULT NULL,
  `activo` tinyint(1) DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'urizarcode@gmail.com','urizarcode@gmail.com','$2a$10$W4TH9e5VSoFQPMcr3t.f9O34SL7Ghr8ZZ4asBui3F.gxTpVZKimzK','Byron Lopez','Google','Ojsah2h5UaTrSDWBGZyxWVAe4wu1','https://lh4.googleusercontent.com/-9EkLLwG-7CU/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucm-K-mnzj5XnGA4KrXoRXOINzSsWQ/photo.jpg',NULL,1,'2020-06-19 22:13:49','2020-06-19 22:13:49'),(2,'blopezu@miumg.edu.gt','blopezu@miumg.edu.gt','$2a$10$tDwYRFKiwtrTwIOBGW7ymO2dKkXOrYEHxFDDctAak.kj9oROxpdYy','BYRON LÓPEZ URIZAR','Google','4L0z9NHnzOaQoOsbmoZFLURVwCG2','https://lh5.googleusercontent.com/-Xo-yGNHgwn4/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucnDl49Hv2oWQ5KfMWvpyJiO2fTwPg/photo.jpg',NULL,1,'2020-06-19 22:30:08','2020-06-19 22:30:08'),(3,'blu.urizar@gmail.com','blu.urizar@gmail.com','$2a$10$GvL/qJhfZfAfP9hKkhfhTuf52tuMQPUdhbaItTZoYCRbQAil62fFC','Byron Lopez','Google','bRmz1pRahwSGYm7pcHnYu04AOVP2','https://lh6.googleusercontent.com/-xMKdTxUc7qg/AAAAAAAAAAI/AAAAAAAAAAA/AMZuucne_M7oHVrzey3q6gKDXqKZrgci-g/photo.jpg',1,1,'2020-06-20 22:39:48','2020-06-20 22:39:48');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-23 21:57:19
